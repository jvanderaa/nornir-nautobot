# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pynautobot', 'pynautobot.core', 'pynautobot.models']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.20.0,<3.0.0', 'six>=1.0.0,<2.0.0']

setup_kwargs = {
    'name': 'pynautobot',
    'version': '1.0.0',
    'description': 'Nautbot API client library',
    'long_description': None,
    'author': 'Network to Code, LLC',
    'author_email': 'info@networktocode.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/networktocode-llc/pynautobot',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*, !=3.4.*, !=3.5.*',
}


setup(**setup_kwargs)
